﻿using System;

namespace MeetingConsoleApp
{
	public record Meeting(
		int Id,
		DateTime Begin, 
		DateTime End,
		TimeSpan Notification
	);
}
