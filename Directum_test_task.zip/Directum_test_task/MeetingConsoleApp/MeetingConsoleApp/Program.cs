﻿using System;

namespace MeetingConsoleApp
{
	class Program
	{
		static MeetingsKeeper meetingsKeeper = new();
		static MeetingNotificationManager meetingNotificationManager = new();

		static void Main(string[] args)
		{
			while (true)
			{
				Console.Write("> ");
				var commandInput = Console.ReadLine();
				var command = ParseCommand(commandInput);
				if (command is null)
					continue;
				var result = command.Execute();
				Console.WriteLine(result);
			}
		}

		private static Command ParseCommand(string command)
		{
			try
			{
				var commandItems = command.Split(' ');
				var commandParseSuccess = Enum.TryParse<CommandAction>(commandItems[0], out var commandAction);
				return commandAction switch
				{
					CommandAction.Add => new AddMeetingCommand(meetingsKeeper, meetingNotificationManager, commandItems),
					CommandAction.Update => new UpdateMeetingCommand(meetingsKeeper, meetingNotificationManager, commandItems),
					CommandAction.Delete => new DeleteMeetingCommand(meetingsKeeper, meetingNotificationManager, commandItems),
					CommandAction.Info => new InfoCommand(),
					CommandAction.GetAll => new GetAllCommand(meetingsKeeper),
					CommandAction.GetByDate => new GetByDateCommand(meetingsKeeper, commandItems),
					CommandAction.Export => new ExportCommand(meetingsKeeper, commandItems),
					_ => new UnexpectedCommand(),
				};
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
				return null;
			}
		}
	}
}
