﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace MeetingConsoleApp
{
	public class MeetingNotificationManager
	{
		private Dictionary<int, CancellationTokenSource> NotificationCancellations = new();

		public void AddOrUpdateNotification(Meeting meeting)
		{
			var notificationDateTime = meeting.Begin.Add(meeting.Notification);
			if (notificationDateTime < DateTime.Now)
			{
				Console.WriteLine("Time for notification is ended.");
				return;
			}

			if (NotificationCancellations.ContainsKey(meeting.Id))
				RemoveNotification(meeting.Id);

			var cancellationTokenSource = new CancellationTokenSource();
			var cancellationToken = cancellationTokenSource.Token;

			var task = Task.Run(() =>
			{
				var notificationAfterMilliseconds = (meeting.Begin.Add(-meeting.Notification) - DateTime.Now).TotalMilliseconds;
				Thread.Sleep((int)notificationAfterMilliseconds);
				if (!cancellationToken.IsCancellationRequested)
					Console.WriteLine($"Meeting {meeting.Begin.Date:MM.dd HH:mm} - {meeting.End.Date:MM.dd HH:mm} " +
						$"will be started after {meeting.Notification.Minutes} minutes.\n" +
						$"> ");
			}, cancellationToken);

			NotificationCancellations.TryAdd(meeting.Id, cancellationTokenSource);
		}

		public void RemoveNotification(int meetingId)
		{
			if (NotificationCancellations.TryGetValue(meetingId, out var cancellationToken))
				cancellationToken.Cancel();

			NotificationCancellations.Remove(meetingId);
		}
	}
}
