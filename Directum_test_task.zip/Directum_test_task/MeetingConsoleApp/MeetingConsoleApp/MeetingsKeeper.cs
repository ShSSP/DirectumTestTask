﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace MeetingConsoleApp
{
	public class MeetingsKeeper
    {
		private Dictionary<int, LinkedListNode<Meeting>> Repository = new();
		private int lastUsedId = 0;

		private LinkedList<Meeting> UpcomingMeetings = new();
		private List<Meeting> OutdatedMeetings = new();

		public Meeting GenirateMeeting(DateTime begin, DateTime end, TimeSpan notification)
		{
			return new Meeting(++lastUsedId, begin, end, notification);
		}

		public Meeting Get(int key)
		{
			return Repository.TryGetValue(key, out var value) ? value?.Value : null;
		}

		public IEnumerable<Meeting> GetAll()
		{
			return OutdatedMeetings.Concat(UpcomingMeetings);
		}

		public IEnumerable<Meeting> GetUpcomingMeetings()
		{
			return UpcomingMeetings;
		}

		public IEnumerable<Meeting> GetMeetingsByDate(DateTime date)
		{
			if (date.Date == DateTime.Now.Date)
				return GetAll().Where(x => x.Begin.Date == date.Date);
			if (date.Date < DateTime.Now.Date)
				return OutdatedMeetings.Where(x => x.Begin.Date == date.Date);

			return UpcomingMeetings.Where(x => x.Begin.Date == date.Date);
		}

		public (bool Success, string Message) Add(Meeting item)
		{
			if (item.Begin < DateTime.Now)
				return (false, "The meeting cannot start earlier than the current time.");

			var isBusy = UpcomingMeetings.Any(x => 
				(x.Begin == item.Begin && x.End == item.End)
				|| (x.Begin < item.Begin && item.Begin < x.End) 
				|| (x.Begin < item.End && item.End < x.End));
			if(isBusy)
				return (false, "Meeting time range is busy.");

			var lastMeeting = UpcomingMeetings.First;
			if (lastMeeting is null || item.End <= lastMeeting.Value.Begin)
			{
				var meetingNode = UpcomingMeetings.AddFirst(item);
				Repository.Add(item.Id, meetingNode);
				return (true, "The meeting is saved.");
			}

			while (lastMeeting is not null)
			{
				var nextMeeting = lastMeeting.Next;
				if(item.Begin >= lastMeeting.Value.End 
					&& nextMeeting is null 
					|| item.End <= nextMeeting.Value.Begin)
				{
					var meetingNode = UpcomingMeetings.AddAfter(lastMeeting, item);
					Repository.Add(item.Id, meetingNode);
					return (true, "The meeting is saved.");
				}
				lastMeeting = nextMeeting;
			}
			throw new ArgumentException("Method doesn't find place to add meeting");
		}

		public (bool Success, string Message) Update(Meeting item)
		{
			if (Repository.ContainsKey(item.Id))
			{
				var meetingNode = Repository[item.Id];
				UpcomingMeetings.Remove(meetingNode);
				Repository.Remove(item.Id);
				return Add(item);
			}
			return (false, "Meeting doesn't exist");
		}

		public (bool Success, string Message) Delete(int id)
		{
			if (Repository.ContainsKey(id))
			{
				var meetingNode = Repository[id];
				UpcomingMeetings.Remove(meetingNode);
				Repository.Remove(id);
				return (true, "Meeting is removed");
			}
			return (false, "Meeting doesn't exist");
		}
    }
}
