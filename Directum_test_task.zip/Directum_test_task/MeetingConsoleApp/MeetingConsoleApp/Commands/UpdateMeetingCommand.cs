﻿using System;

namespace MeetingConsoleApp
{
	public class UpdateMeetingCommand : Command
	{
		private readonly MeetingsKeeper meetingsKeeper;
		private readonly MeetingNotificationManager notificationManager;
		private readonly int id;
		private readonly DateTime begin;
		private readonly DateTime end;
		private readonly TimeSpan notification;

		public UpdateMeetingCommand(
			MeetingsKeeper meetingsKeeper, 
			MeetingNotificationManager notificationManager, 
			string[] commandItems)
		{
			this.meetingsKeeper = meetingsKeeper;
			this.notificationManager = notificationManager;
			id = int.Parse(commandItems[1]);
			begin = DateTime.ParseExact(commandItems[2], DATE_TIEM_PARSE_FORMAT, null);
			end = DateTime.ParseExact(commandItems[3], DATE_TIEM_PARSE_FORMAT, null);
			notification = TimeSpan.FromMinutes(int.Parse(commandItems[4]));
		}

		public override string Execute()
		{
			var meeting = new Meeting(id, begin, end, notification);
			var (success, message) = meetingsKeeper.Update(meeting);
			if (success)
				notificationManager.AddOrUpdateNotification(meeting);
			return message;
		}
	}
}
