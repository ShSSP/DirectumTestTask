﻿using System;
using System.IO;
using System.Linq;

namespace MeetingConsoleApp
{
	public class ExportCommand : Command
	{
		MeetingsKeeper meetingsKeeper;
		DateTime date;
		string pathFolder;

		public ExportCommand(MeetingsKeeper meetingsKeeper, string[] commandItems)
		{
			this.meetingsKeeper = meetingsKeeper;
			date = DateTime.ParseExact(commandItems[1], DATE_TIEM_PARSE_FORMAT, null);
			pathFolder = commandItems[2];
		}

		public override string Execute()
		{
			var meetings = meetingsKeeper.GetMeetingsByDate(date);
			var meetingInfos = meetings.Select(x => x.ToString())
				.ToList();
			var fullFilePath = Path.Combine(pathFolder, $"meetings_{date:dd.MMM.yyyy}.txt");
			File.WriteAllLines(fullFilePath, meetingInfos);
			return "Export ended correctly.";
		}
	}
}
