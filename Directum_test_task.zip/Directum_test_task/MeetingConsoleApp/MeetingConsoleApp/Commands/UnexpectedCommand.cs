﻿namespace MeetingConsoleApp
{
	public class UnexpectedCommand : Command
	{
		public override string Execute() => 
			"Unexpected meeting command;\n" +
			"Use 'Info' command for get information for allowed commands.";
	}
}
