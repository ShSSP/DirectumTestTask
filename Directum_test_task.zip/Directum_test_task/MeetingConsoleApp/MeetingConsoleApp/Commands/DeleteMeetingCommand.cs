﻿namespace MeetingConsoleApp
{
	public class DeleteMeetingCommand : Command
	{
		private readonly MeetingsKeeper meetingsKeeper;
		private readonly MeetingNotificationManager notificationManager;
		private readonly int id;

		public DeleteMeetingCommand(
			MeetingsKeeper meetingsKeeper, 
			MeetingNotificationManager notificationManager, 
			string[] commandItems)
		{
			this.meetingsKeeper = meetingsKeeper;
			this.notificationManager = notificationManager;
			id = int.Parse(commandItems[1]);
		}

		public override string Execute()
		{
			var (success, message) = meetingsKeeper.Delete(id);
			if (success)
				notificationManager.RemoveNotification(id);
			return message;
		}
	}
}
