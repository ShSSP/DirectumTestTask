﻿namespace MeetingConsoleApp
{
	public class InfoCommand : Command
	{
		public override string Execute() =>
			"Commands:\n" +
			"Info\n" +
			"GetAll\n" +
			"GetByDate date\n" +
			"Export date path_folder\n" +
			"Add begin_meeting_date_time end_meeting_date_time notification_minutes_before_start\n" +
			"Update meeting_id begin_meeting_date_time end_meeting_date_time notification_minutes_before_start\n" +
			"Delete meeting_id\n";
	}
}
