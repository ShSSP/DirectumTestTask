﻿namespace MeetingConsoleApp
{
	public class GetAllCommand : Command
	{
		private readonly MeetingsKeeper meetingsKeeper;

		public GetAllCommand(MeetingsKeeper meetingsKeeper)
		{
			this.meetingsKeeper = meetingsKeeper;
		}

		public override string Execute()
		{
			return string.Join("\n", meetingsKeeper.GetAll());
		}
	}
}
