﻿using System;

namespace MeetingConsoleApp
{
	public class AddMeetingCommand : Command
	{
		private readonly MeetingsKeeper meetingsKeeper;
		private readonly MeetingNotificationManager notificationManager;
		private readonly DateTime begin;
		private readonly DateTime end;
		private readonly TimeSpan notification;

		public AddMeetingCommand(
			MeetingsKeeper meetingsKeeper, 
			MeetingNotificationManager notificationManager, 
			string[] commandItems)
		{
			this.meetingsKeeper = meetingsKeeper;
			this.notificationManager = notificationManager;
			begin = DateTime.ParseExact(commandItems[1], DATE_TIEM_PARSE_FORMAT, null);
			end = DateTime.ParseExact(commandItems[2], DATE_TIEM_PARSE_FORMAT, null);
			notification = TimeSpan.FromMinutes(int.Parse(commandItems[3]));
		}

		public override string Execute()
		{
			var meeting = meetingsKeeper.GenirateMeeting(begin, end, notification);
			var (success, message) = meetingsKeeper.Add(meeting);
			if(success)
				notificationManager.AddOrUpdateNotification(meeting);
			return message;
		}
	}
}
