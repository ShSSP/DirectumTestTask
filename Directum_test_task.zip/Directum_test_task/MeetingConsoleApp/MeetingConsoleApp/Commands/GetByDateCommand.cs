﻿using System;

namespace MeetingConsoleApp
{
	public class GetByDateCommand : Command
	{
		private readonly MeetingsKeeper meetingsKeeper;
		private readonly DateTime date;

		public GetByDateCommand(MeetingsKeeper meetingsKeeper, string[] commandItems)
		{
			this.meetingsKeeper = meetingsKeeper;
			date = DateTime.ParseExact(commandItems[1], DATE_TIEM_PARSE_FORMAT, null);
		}

		public override string Execute()
		{
			var meetings = meetingsKeeper.GetMeetingsByDate(date);
			return string.Join("\n", meetings);
		}
	}
}
