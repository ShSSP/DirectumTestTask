﻿namespace MeetingConsoleApp
{
	public abstract class Command
	{
		protected const string DATE_TIEM_PARSE_FORMAT = "yyyy-MM-ddHH:mm";
		public abstract string Execute();
	}
}
