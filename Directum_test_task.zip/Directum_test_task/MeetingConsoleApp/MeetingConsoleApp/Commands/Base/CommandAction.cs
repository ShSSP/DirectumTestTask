﻿namespace MeetingConsoleApp
{
	public enum CommandAction
	{
		Unexpected,
		Info,
		GetAll,
		GetByDate,
		Export,
		Add,
		Update,
		Delete
	}
}
